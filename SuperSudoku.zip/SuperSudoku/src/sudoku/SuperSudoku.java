package sudoku;

import conjuntos.ConjuntoA;
import conjuntos.ConjuntoADT;
import conjuntos.LineaSudo;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 * Clase SuperSudoku
 
 25-04-2019
 * @author María José Domenzain C.U. 1517144
 * @author Montserrat Olivares  C.U. 179905
 * @author Sebastián Zárate     C.U. 180087
 * @author Rodrigo González     C.U. 183873
 */
public class SuperSudoku {
    
    private static int[][] sudoku;
    private static long incioDeSolucion;//Tiempo
    private static long tiempoMaximoSolucion;//Tiempo
    private static ConjuntoADT<Integer> rengs[];
    private static ConjuntoADT<Integer> cols[];
    private static ConjuntoADT<Integer> bloques[][]; //3x3 para representar mejor matriz de bloques
    private static final int MAXIMO = 9;//MAX RENGS Y COLS
    
    /**
     * Método que agrega un valor a matriz sudoku, rengs, cols y bloques
     * @param renglon entero que representa renglón de matriz sudoku
     * @param columna entero que representa columna de matriz sudoku
     * @param valor entero que representa un valor a remover en sudoku, rengs, cols o bloques
     * @return <ul>
     *      <li>true: si se agrega exitosamente valor a matrices sudoku, rengs, cols y bloques</li>
     *      <li>false: si no se logra agregar el valor de forma exitosa</li>
     *      </ul>
     */
    public static boolean agrega(int renglon, int columna, int valor) throws Exception{
        boolean res;
        
        if(valoresValidos(renglon, columna, valor)) {
            sudoku[renglon][columna] = valor;
            res = rengs[renglon].add(valor);
            res = (cols[columna].add(valor) && res);
            res = (bloques[getBloqVal(renglon)][getBloqVal(columna)].add(valor) && res);
        } else
            throw new Exception("Valor es invalido: "+ valor);
        return res; //manda false si alguno de los valores se encuentra repetido
    }
    
    /**
     * Método que elimina un elemento de matrices sudoku, rengs, cols y bloques
     * @param renglon entero que representa renglón de matriz sudoku
     * @param columna entero que representa columna de matriz sudoku
     * @param valor entero que representa un valor a remover en sudoku, rengs, cols o bloques
     * @return <ul>
     *      <li>true: si se elimina exitosamente valor a matrices sudoku, rengs, cols y bloques</li>
     *      <li>false: si no se logra remover el valor de forma exitosa</li>
     *      </ul>
     */
    private static int quita (int renglon, int columna, int valor) throws Exception {
        int res;
        
        if(valoresValidos(renglon, columna, valor)) {
            sudoku[renglon][columna] = 0;
            res = (int) rengs[renglon].quita(valor);
            cols[columna].quita(valor);
            bloques[getBloqVal(renglon)][getBloqVal(columna)].quita(valor);
        } else
            throw new Exception("Valor es invalido: "+ valor);
        return res;
    }
    
    /**
     * Método que verifica si el valor es contenido por matrices rengs, cols o bloques
     * 
     * @param renglon entero que representa renglón de matriz sudoku
     * @param columna entero que representa columna de matriz sudoku
     * @param valor entero que representa un valor a verificar si es contenido por rengs, cols o bloques
     * @return <ul>
     *      <li>true: si no se contiene valor en matrices rengs, cols y bloques</li>
     *      <li>false: si ya se contiene el valor en matrices rengs, cols y bloques</li>
     *      </ul>
     */
    private static boolean verifica (int renglon, int columna, int valor) {
        boolean res;
        
        if(valoresValidos(renglon, columna, valor)) {
            res = !rengs[renglon].contains(valor);
            res = res && !cols[columna].contains(valor);
            res = res && !bloques[getBloqVal(renglon)][getBloqVal(columna)].contains(valor);
        }
        else
            res = false;
        return res;
    }
    
    /**
     * Método que verifica validez de valores ingresados
     * @param ren entero que representa renglón de matriz sudoku
     * @param col entero que representa columna de matriz sudoku
     * @param val entero que representa un valor a ingresar o remover de matriz sudoku
     * @return true si ren col y val estan en rango apropiado de valores (0-8) o (1-9)
     */
    public static boolean valoresValidos(int ren, int col, int val) {
        return ren >= 0 && ren < MAXIMO && col >= 0 && col < MAXIMO && val >= 1 && val <= 9;
    }
    
    /**
     * <pre> Método auxiliar para obtener las posiciones equivalentes de renglón y 
     * columna para la matriz bloques. </pre>
     * @param valor entero que representa columna y/o renglón de matriz sudoku
     * @return entero entre 0 y 2 que representa el cuadrante correspondiente en el que el valor se encuentra.
     */
    public static int getBloqVal (int valor) {
        int res;
        
        res = 0;
        switch(valor/3) {
            case 0: res = 0; break;
            case 1: res = 1; break;
            default: res = 2;
        }
        return res;
    }
    
    /**
     * Método auxiliar que maneja el cambio de posicion para el metodo resuelve
     * @param renglon entero que representa renglón de matriz sudoku
     * @param columna entero que representa renglón de matriz sudoku
     * @return <pre> arreglo entero de dos posiciones que contiene 
     *              la siguiente posición que el algoritmo recursivo resuelve puede moverse:
     *              agrega 1 a columna si es posible, en caso contrario suma 1 a renglón y convierte
     *              columna en 0.</pre>
     * @see resuelve
     */
    private static int[] cambiaPos(int renglon, int columna){
        int[] posicion;
        
        posicion = new int[2];
        if(columna == MAXIMO - 1){
            if(renglon < MAXIMO - 1){
                posicion[0] = renglon + 1;
                posicion[1] = 0;  
            }
            else{
                posicion[0] = 9;
            }    
        }
        else{//Me voy al siguiente cuadrado y empiezo a intentar
            posicion[0] = renglon;
            posicion[1] = columna + 1;
        }
        return posicion;
    }

    /**
     * Método recursivo que completa matriz sudoku
     * 
     * @param renglon entero que representa renglón de matriz sudoku
     * @param columna entero que representa columna de matriz sudoku
     * @return <ul>
     *      <li>true: si logra completar el sudoku de forma exitosa</li>
     *      <li>false: si el tiempo de procesamiento supera el tiempoMaximoSolucion
     *          o si no existe solución al sudoku</li>
     *      </ul>
     * @throws Exception si agrega o quita manda Exception
     * @see resuelve, quita, agrega
     */
    private static boolean resuelve(int renglon, int columna) throws Exception{
        int numero, posiciones[];
        
        if(System.currentTimeMillis() > tiempoMaximoSolucion)//tiempo maximo para resolver
            return false;
        if(renglon == MAXIMO)//Estado base
            return true;
        if(sudoku[renglon][columna] != 0){
            posiciones = cambiaPos(renglon, columna);
            return resuelve(posiciones[0], posiciones[1]);
        }
        else{    
            for(numero = 1; numero <= MAXIMO; numero++){
                if(verifica(renglon, columna, numero)){
                    if(!agrega(renglon, columna, numero))
                        continue;
                    posiciones = cambiaPos(renglon, columna); //Mover a la siguiente casilla
                    if(resuelve(posiciones[0], posiciones[1]))
                        return true;
                    else
                        quita(renglon, columna, numero);//La solucion que estaba no es valida
                }
            }
            return false;//Ningun numero del 1-9 sirve
        }
    }

    /**
     * <pre> Método que toma una matriz y la copia a la matriz sudoku para intentar resolver
     *       e inicializa y llena matrices rengs, cols y bloques.</pre>
     * @param mat matriz representado al sudoku a resolver
     * @return la matriz resuelta o null si no se logra resolver.
     * 
     * @throws Exception si hay un error en resuelve(ren, col)
     */
    public static int[][] resuelve(int[][] mat) throws Exception{
        incioDeSolucion = System.currentTimeMillis();
        tiempoMaximoSolucion = incioDeSolucion + 10 * 1000;
        sudoku = mat;
        rengs = new ConjuntoA[MAXIMO];
        cols = new ConjuntoA[MAXIMO];
        bloques = new ConjuntoA[MAXIMO/3][MAXIMO/3];
        for(int k = 0; k < MAXIMO; k++) {
            rengs[k] = new ConjuntoA();
            cols[k] = new ConjuntoA();
        }
        for(int j = 0; j < MAXIMO/3; j++)
            for(int k = 0; k < MAXIMO/3; k++)
                bloques[j][k] = new ConjuntoA<>();
        
        for(int k = 0; k < MAXIMO; k ++) {
            for(int j = 0; j < MAXIMO; j++)
                if(sudoku[k][j] != 0) {
                    agrega(k, j, sudoku[k][j]);
                }
        }
        if(!resuelve(0, 0))
            sudoku = null;
        return sudoku;
    }
    
    /**
     * Este metodo es usado por la interfaz para verificar en tiempo real 
     * los numeros ingresados y mandar las excepciones correspondientes
     * @param casilla es la casilla en la interface donde se introduce el numero
     * @param ev es la combinacion escrita en el teclaco, sirve para ver valores
     * @param x Coordenada x de la matriz donde se encontrara el numero
     * @param y Coordenada y de la donde se encontrara 
     * @param sudokuLineasHorizontales representa lineas horizontales del sudoku
     * @param sudokuLineasVerticales representa lineas verticales del sudoku
     * @param sudokuCuadro son los grupos del sudoku
     * @param cuadro es una base para ver el digito al que 
     * pertenece en la matriz
     * @param sudoku es la matriz sudoku
     */
     public static void verificaNumero(JTextField casilla, KeyEvent ev, int x,
            int y, LineaSudo[] sudokuLineasHorizontales, 
            LineaSudo[] sudokuLineasVerticales, LineaSudo[] sudokuCuadro, 
            int[][] cuadro, int[][] sudoku ){
         
            char digi=ev.getKeyChar();
            int num,remo=sudoku[x][y];
            
            if(casilla.getText().length()>0){
                casilla.setText("");
                if(((remo > 0) && (remo <= 9))){
                    sudokuLineasHorizontales[y].remove(remo);
                    sudokuLineasVerticales[x].remove(remo);
                    sudokuCuadro[cuadro[x][y]].remove(remo);
                }
            }
            if(((digi > '0') && (digi <= '9'))){
                num=Integer.parseInt(""+digi);

                if(!sudokuLineasHorizontales[y].contains(num)&&
                        !sudokuLineasVerticales[x].contains(num)&&
                        !sudokuCuadro[cuadro[x][y]].contains(num)){

                    sudokuLineasHorizontales[y].add(num);
                    sudokuLineasVerticales[x].add(num);
                    sudokuCuadro[cuadro[x][y]].add(num);
                    sudoku[x][y]=num;
                }
                else{
                    JOptionPane.showMessageDialog(null, 
                    "El numero ingresado ya se encuentra en la misma fila, "
                            + "columna o cuadro");
                    casilla.setText("");
                    sudoku[x][y]=0;
                }
            }
            else{
                if(((int)digi)!=8){
                    JOptionPane.showMessageDialog(null, 
                            "El caracter ingresado no es válido");
                }
                casilla.setText("");
                sudoku[x][y]=0;
            }
         }
}

