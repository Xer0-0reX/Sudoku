/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conjuntos;

/**
 *
 * @author rosendo
 */
public class LineaSudo extends  ConjuntoA {
    private ConjuntoA<Integer> lin;
    private int card;

    public LineaSudo() {
        lin=new ConjuntoA(9);
        card=0;
    }
    
    public void add(int num){
        lin.add(num);
        card++;
    }
    
    public boolean contains(int num){
        return lin.contains(num);
    }
    
    public int remove(int num){
        card--;
        return lin.quita(num);
    }

    public int getCardinalidad() {
        return card;
    }
    
    public int sumaElem(){
        return lin.sumaElementos();
    }
    
    
    
    
}
