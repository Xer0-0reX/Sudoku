package conjuntos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Iterator;

/**
 * Clase ConjuntoADT
 * 
 * 25-04-2019
 * @author María José Domenzain C.U. 1517144
 * @author Montserrat Olivares  C.U. 179905
 * @author Sebastián Zárate     C.U. 180087
 * @author Rodrigo González     C.U. 183873
 * 
 * @param <T>
 */
public interface ConjuntoADT <T> extends Iterable<T>{
    boolean contains(T dato);
    boolean isEmpty();
    boolean add(T dato);
    T quita(T dato);
    ConjuntoADT<T> union(ConjuntoADT<T> conjunto);
    ConjuntoADT<T> interseccion(ConjuntoADT<T> conjunto);
    ConjuntoADT<T> diferencia(ConjuntoADT<T> conjunto);
    Iterator<T> iterator();
    int getCardinalidad();
    String toString();
    boolean equals(ConjuntoADT<T> otro);
    
}
