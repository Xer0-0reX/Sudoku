/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sudoku;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author szaratem
 */
public class SuperSudokuTest {
    
    public SuperSudokuTest() {
    }

    /**
     * Test of agrega method, of class SuperSudoku.
     */
    @Test
    public void testAgrega() throws Exception {
        System.out.println("agrega");
        int renglon = 1;
        int columna = 1;
        int valor = 3;
        boolean expResult = true;
        boolean result = SuperSudoku.agrega(renglon, columna, valor);
        assertEquals(expResult, result);
        
        renglon = 1;
        columna = 2;
        valor = 1;
        expResult = true;
        result = SuperSudoku.agrega(renglon, columna, valor);
        assertEquals(expResult, result);
    }

    /**
     * Test of valoresValidos method, of class SuperSudoku.
     */
    @Test
    public void testValoresValidos() {
        System.out.println("valoresValidos");
        int ren = 0;
        int col = 0;
        int val = 0;
        boolean expResult = false;
        boolean result = SuperSudoku.valoresValidos(ren, col, val);
        assertEquals(expResult, result);
        
        ren = 1;
        col = 3;
        val = 1;
        expResult = true;
        result = SuperSudoku.valoresValidos(ren, col, val);
        assertEquals(expResult, result);
        
        ren = 10;
        col = 3;
        val = 1;
        expResult = false;
        result = SuperSudoku.valoresValidos(ren, col, val);
        assertEquals(expResult, result);
    }

    /**
     * Test of getBloqVal method, of class SuperSudoku.
     */
    @Test
    public void testGetBloqVal() {
        System.out.println("getBloqVal");
        int valor = 1;
        int expResult = 0;
        int result = SuperSudoku.getBloqVal(valor);
        assertEquals(expResult, result);
        
        valor = 6;
        expResult = 2;
        result = SuperSudoku.getBloqVal(valor);
        assertEquals(expResult, result);
    }

    /**
     * Test of resuelve method, of class SuperSudoku.
     */
    @Test
    public void testResuelve() throws Exception {
        System.out.println("resuelve");
        int[][] mat = {{ 8, 0, 0, 0, 0, 0, 0, 0, 0},
                      { 0, 0, 3, 6, 0, 0, 0, 0, 0},
                      { 0, 7, 0, 0, 9, 0, 2, 0, 0},
                      { 0, 5, 0, 0, 0, 7, 0, 0, 0},
                      { 0, 0, 0, 0, 4, 5, 7, 0, 0},
                      { 0, 0, 0, 1, 0, 0, 0, 3, 0},
                      { 0, 0, 1, 0, 0, 0, 0, 6, 8},
                      { 0, 0, 8, 5, 0, 0, 0, 1, 0},
                      { 0, 9, 0, 0, 0, 0, 4, 0, 0}};
        int[][] expResult = {{8, 1, 2, 7, 5, 3, 6, 4, 9},
                            {9, 4, 3, 6, 8, 2, 1, 7, 5},
                            {6, 7, 5, 4, 9, 1, 2, 8, 3},
                            {1, 5, 4, 2, 3, 7, 8, 9, 6},
                            {3, 6, 9, 8, 4, 5, 7, 2, 1},
                            {2, 8, 7, 1, 6, 9, 5, 3, 4},
                            {5, 2, 1, 9, 7, 4, 3, 6, 8},
                            {4, 3, 8, 5, 2, 6, 9, 1, 7},
                            {7, 9, 6, 3, 1, 8, 4, 5, 2}};
        int[][] result = SuperSudoku.resuelve(mat);
        assertArrayEquals(expResult, result);
        
        int [][] mat2 = {{ 8, 0, 0, 0, 0, 0, 0, 0, 0},
                      { 8, 0, 3, 6, 0, 0, 0, 0, 0},
                      { 0, 7, 0, 0, 9, 0, 2, 0, 0},
                      { 0, 5, 0, 0, 0, 7, 0, 0, 0},
                      { 0, 0, 0, 0, 4, 5, 7, 0, 0},
                      { 0, 0, 0, 1, 0, 0, 0, 3, 0},
                      { 0, 0, 1, 0, 0, 0, 0, 6, 8},
                      { 0, 0, 8, 5, 0, 0, 0, 1, 0},
                      { 0, 9, 0, 0, 0, 0, 4, 0, 0}};
        expResult = null;
        result = SuperSudoku.resuelve(mat2);
        assertArrayEquals(expResult, result);
    }
    
}
